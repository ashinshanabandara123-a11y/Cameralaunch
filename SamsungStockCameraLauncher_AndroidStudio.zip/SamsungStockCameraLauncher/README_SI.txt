Samsung Stock Camera Launcher - Android Studio Project

මෙම app එක open කළ විට Samsung Stock Camera app එක කෙළින්ම open කිරීමට උත්සාහ කරයි.
මෙය camera app එකක් නැවත නිර්මාණය කරන්නේ නැත; Samsung Camera app එක launch කරන shortcut/launcher එකකි.

Install / Build:
1. ZIP එක extract කරන්න.
2. Android Studio open කර Extract කළ SamsungStockCameraLauncher folder එක තෝරන්න.
3. Gradle Sync අවසන් වනතුරු ඉන්න.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
5. APK එක app/build/outputs/apk/debug/ තුළ ලැබේ.

Device:
- Samsung Galaxy A05 / One UI 7 සඳහා සකස් කළ project එකකි.
- Samsung Camera package name එක com.sec.android.app.camera ලෙස භාවිතා කරයි.
- Samsung Camera app එක device එකේ තිබිය යුතුය.

සටහන:
මෙය source project ZIP එකකි; දැනටමත් compile කළ APK එකක් නොවේ.
Samsung firmware එක අනුව Camera app package/launch behaviour වෙනස් විය හැක.
