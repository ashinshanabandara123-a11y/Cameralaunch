package com.example.samsungstockcameralauncher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Launch the installed Samsung Camera app directly.
        val samsungCameraPackage = "com.sec.android.app.camera"
        val cameraIntent = packageManager.getLaunchIntentForPackage(samsungCameraPackage)

        if (cameraIntent != null) {
            cameraIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(cameraIntent)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(
                    this,
                    "Samsung Camera could not be opened on this device.",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(
                this,
                "Samsung Stock Camera app was not found.",
                Toast.LENGTH_LONG
            ).show()
        }

        finish()
    }
}
