# Camera Launcher

A tiny Android app with a separate launcher icon. Tapping it asks Android to open the
camera app installed on the phone, then closes the launcher activity.

## Open in Android Studio

1. Extract this ZIP file.
2. In Android Studio, choose **File → Open** and select the extracted `CameraLauncher` folder.
3. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks for a Gradle JDK.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run** to install the app.

## Build an APK

In Android Studio, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
The debug APK is normally created at:

`app/build/outputs/apk/debug/app-debug.apk`

## Notes

- App label: `Camera`
- Application ID: `com.example.cameralauncher`
- Minimum Android version: Android 6.0 (API 23)
- No camera permission is requested because the app launches the phone's camera app
  rather than accessing the camera hardware itself.
- The exact camera UI opened is chosen by Android and the device manufacturer. Some
  phones may show a chooser or a camera app selection prompt if multiple apps handle
  the camera intent.
