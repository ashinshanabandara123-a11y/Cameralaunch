package com.example.cameralauncher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Open the phone's installed camera app, then close this launcher activity.
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        try {
            startActivity(cameraIntent)
        } catch (_: ActivityNotFoundException) {
            // Some devices expose the camera through this alternate action.
            try {
                startActivity(Intent("android.media.action.STILL_IMAGE_CAMERA"))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "No camera app found on this device.", Toast.LENGTH_LONG).show()
            }
        }

        finish()
    }
}
